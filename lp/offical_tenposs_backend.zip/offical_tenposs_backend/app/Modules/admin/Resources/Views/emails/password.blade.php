Click here to reset your password: {{ route('admin.auth.resetForm',$token) }}
